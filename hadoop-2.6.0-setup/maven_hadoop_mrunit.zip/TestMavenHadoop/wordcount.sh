#!/usr/bin/bash

hdfs dfs -rm -r output
hadoop jar target/TestMavenHadoop-0.0.1-SNAPSHOT.jar test.hadoop.WordCountDriver input output
echo 'Job Input'
echo '----------'
echo ''
hdfs dfs -ls input
echo ''
echo 'Job Output'
echo '----------'
hdfs dfs -cat output/part-r-00000
